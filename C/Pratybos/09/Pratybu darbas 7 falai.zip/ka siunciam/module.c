#include "module.h"
int execute(int a1, int a2, int f(int a,int b)){
	return f(a1,a2);
}
