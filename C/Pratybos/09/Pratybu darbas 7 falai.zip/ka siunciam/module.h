#ifndef GUARDmodule
#define GUARDmodule
int execute(int a1, int a2, int f(int a,int b));
#endif
