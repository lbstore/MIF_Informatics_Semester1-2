#ifndef GUARDmod
#define GUARDmod
int add(int a1, int a2);
int sub(int a1, int a2);
int findAddCount();
int findSubCount();
int findTotalCount();
#endif
