#include <stdlib.h>
#include <stdio.h>
#include "BSTmodule.h" 


void initialize(bstNode** node, void* data){
	*node = newNode(data);
}

bstNode* newNode(void* data){
	bstNode* tmpNode = malloc(sizeof(bstNode));
	tmpNode->data=data;
	tmpNode->left = NULL;
	tmpNode->right = NULL;
	return tmpNode;
}


bstNode** search(bstNode** root, int cmp(void* a, void* b), void* data){
	bstNode** node = root;
	while ((*node) != NULL) {
		int cmpResult = cmp(data, (*node)->data);
		if (cmpResult < 0)
			node = &(*node)->left;
		else if (cmpResult > 0)
			node = &(*node)->right;
		else
			break;
	}
	return node;
}

void insert(bstNode** root, int cmp(void* a, void*b), void* data){
	bstNode** node = search(root, cmp, data);
	if (*node == NULL) {
		*node = newNode(data);
	}
}

void freeNode(bstNode* node){
	free(node);
}

void clearTree(bstNode** node){
	if ((*node) == NULL) return;
	
	clearTree(&(*node)->left);
	clearTree(&(*node)->right);
	freeNode(*node);
}
