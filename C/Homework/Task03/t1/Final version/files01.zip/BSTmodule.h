#ifndef BSTmoduleGUARD
#define BSTmoduleGUARD

//Author: Laimonas Beniušis VU MIF INFORMATIKA 1
//conatact: aciukadsiunciate@gmail.com

typedef struct bstNode {
    void* data;
    struct bstNode* left;
	struct bstNode* right;
}bstNode; 

void initialize(bstNode** node, void* data);
bstNode* newNode(void* data);
void insert(bstNode** root, int cmp(void* a, void*b), void* data);
bstNode** search(bstNode** root, int cmp(void* a, void* b), void* data);
void freeNode(bstNode* node);
void clearTree(bstNode** node);
#endif
